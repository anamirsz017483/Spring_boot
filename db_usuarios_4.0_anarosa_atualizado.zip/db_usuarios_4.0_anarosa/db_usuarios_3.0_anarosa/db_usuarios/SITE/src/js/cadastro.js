const API = "http://localhost:8080/usuarios";

document.getElementById("formCadastro")
    .addEventListener("submit", function (e) {
        e.preventDefault();

        const usuario = {
            nome: nome.value,
            email: email.value,
            senha: senha.value,
            perfil: perfil.value,
            endereco: endereco.value,
            bairro: bairro.value,
            complemento: complemento.value,
            cep: cep.value,
            cidade: cidade.value,
            estado: estado.value

        };

        fetch(API, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(usuario)
        })
            .then(res => {
                if (!res.ok) throw new Error("Erro ao cadastrar");
                return res.json();
            })
            .then(() => {
                alert("Usuário cadastrado com sucesso!");
                window.location.href = "usuarios.html";
            })
            .catch(err => alert(err.message));
    });

function voltar() {
    window.location.href = "main.html";
}

const form = document.getElementById('formUsuario');

const nome = document.getElementById('nome');
const email = document.getElementById('email');
const perfil = document.getElementById('perfil');
const cidade = document.getElementById('cidade');
const estado = document.getElementById('estado');
const fotoInput = document.getElementById('fotoInput');
const preview = document.getElementById('preview');

let fotoBase64 = "";

// ler a foto inserida 
fotoInput.addEventListener('change', function () {

    const arquivo = this.files[0];

    if (arquivo) {

        const reader = new FileReader();

        reader.onload = function (e) {

            fotoBase64 = e.target.result;
            preview.src = fotoBase64;
            preview.style.display = 'block';

        };

        reader.readAsDataURL(arquivo);

    }

});


// Enviar formulário
form.addEventListener('submit', function (e) {

    e.preventDefault();

    const usuario = {

        nome: nome.value,
        email: email.value,
        perfil: perfil.value,
        cidade: cidade.value,
        estado: estado.value,
        foto: fotoBase64

    };

    console.log(usuario);

});

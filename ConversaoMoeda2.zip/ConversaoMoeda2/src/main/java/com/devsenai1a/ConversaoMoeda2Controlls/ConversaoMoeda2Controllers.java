package com.devsenai1a.ConversaoMoeda2Controlls;
import java.util.HashMap;
import java.util.Map;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/conversor")
public class ConversaoMoeda2Controllers {

@GetMapping("/converter")
public Map<String, Object> converter(
@RequestParam String moedaOrigem,
@RequestParam double valor) {


}
}

Map<String, Object> resposta = new HashMap<>();
Map<String, Double> conversoes = new HashMap<>();

double taxaUSD = 5.6;
double taxaEUR = 6.1;

if (moedaOrigem.equalsIgnoreCase("real")) {
conversoes.put("USD", valor / taxaUSD);
conversoes.put("EUR", valor / taxaEUR);
} else if (moedaOrigem.equalsIgnoreCase("dolar")) {
conversoes.put("BRL", valor * taxaUSD);
conversoes.put("EUR", valor * (taxaUSD / taxaEUR));
} else if (moedaOrigem.equalsIgnoreCase("euro")) {
conversoes.put("BRL", valor * taxaEUR);
conversoes.put("USD", valor * (taxaEUR / taxaUSD));
} else {
resposta.put("erro", "Moeda de origem inválida!");
return resposta;
}

resposta.put("moedaOrigem", moedaOrigem);
resposta.put("valorOriginal", valor);
resposta.put("conversoes", conversoes);

return resposta;
}
}
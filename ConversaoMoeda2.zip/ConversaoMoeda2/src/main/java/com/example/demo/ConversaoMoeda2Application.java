package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConversaoMoeda2Application {

	public static void main(String[] args) {
		SpringApplication.run(ConversaoMoeda2Application.class, args);
	}

}

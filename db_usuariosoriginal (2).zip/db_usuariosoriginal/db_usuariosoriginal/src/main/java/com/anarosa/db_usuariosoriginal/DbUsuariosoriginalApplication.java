package com.anarosa.db_usuariosoriginal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DbUsuariosoriginalApplication {

	public static void main(String[] args) {
		SpringApplication.run(DbUsuariosoriginalApplication.class, args);
	}

}

package com.anarosa.db_usuariosoriginal.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.anarosa.db_usuariosoriginal.entity.Usuario;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
Usuario findByEmail(String email);
}
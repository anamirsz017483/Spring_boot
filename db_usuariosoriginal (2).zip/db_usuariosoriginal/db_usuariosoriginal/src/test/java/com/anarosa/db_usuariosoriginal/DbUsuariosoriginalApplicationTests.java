package com.anarosa.db_usuariosoriginal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbUsuariosoriginalApplicationTests {

	@Test
	void contextLoads() {
	}

}

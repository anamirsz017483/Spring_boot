
document.getElementById("formCadastro").addEventListener("submit", function (e) {
    e.preventDefault();

    const dados = {
        nome: document.getElementById("nome").value,
        email: document.getElementById("email").value,
        senha: document.getElementById("senha").value,
        perfil: document.getElementById("perfil").value,
        endereco: document.getElementById("endereco").value,
        bairro: document.getElementById("bairro").value,
        complemento: document.getElementById("complemento").value,
        cep: document.getElementById("cep").value,
        cidade: document.getElementById("cidade").value,
        estado: document.getElementById("estado").value,
    };

    console.log("Usuário cadastrado:", dados);
    alert("Usuário salvo com sucesso!");
});